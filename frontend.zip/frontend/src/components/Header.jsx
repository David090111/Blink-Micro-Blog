// Header.jsx
import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthProvider";

function Badge({ children }) {
  return (
    <span className="inline-flex items-center rounded-full bg-indigo-50 px-2 py-0.5 text-xs font-medium text-indigo-700 ring-1 ring-inset ring-indigo-200">
      {children}
    </span>
  );
}

export default function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="flex items-center justify-between py-4">
      <div className="flex items-center gap-2">
        <Link to="/" className="text-2xl font-bold tracking-tight">
          Blink
        </Link>
        <Badge>Micro-Blog</Badge>
      </div>

      <nav className="flex items-center gap-3">
        <Link className="text-gray-700 hover:text-indigo-600" to="/posts">
          Posts
        </Link>

        {user ? (
          <>
            <button
              onClick={() => navigate("/posts/new")}
              className="rounded-xl bg-indigo-600 text-white px-3 py-1.5 hover:bg-indigo-700"
            >
              New Post
            </button>
            <button
              onClick={logout}
              className="rounded-xl bg-gray-900 text-white px-3 py-1.5"
            >
              Logout
            </button>
          </>
        ) : (
          <>
            <Link className="text-indigo-600 hover:underline" to="/login">
              Login
            </Link>
            <Link className="text-indigo-600 hover:underline" to="/register">
              Register
            </Link>
          </>
        )}
      </nav>
    </header>
  );
}
